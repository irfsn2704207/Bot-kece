// UDAH DIKASIH SCRIPTNYA MASA GA SUBSCRIBE
// SUBS MY CHANNEL = FallXD425
// Sc Ini Free Jangan Sampai Kalian Jual Kasian orang yang sudah Membelinya dan tau nya ternyata Gratis di Channel FallXd. Script Free No Encript hanya ada di Channel FallXd 

//==============[ Baca Tulisan Diatas ]==========//

const fs = require('fs')
//=============[ ----- ]============//

//==========================//

// Sosial Media 
global.gr = 'https://youtube.com/@FallXD425' // gausah di ubah :v
global.wagc = "https://whatsapp.com/channel/0029VaBOlsv002TEjlntTE2D" // yg ini silahkan ubah
global.ig = '@fallxd_781' // ubah aja
global.email = 'naufalwijaya438@gmail.com' //serah
global.region = 'indonesia' // serah
global.ownername = '𝑭𝒍𝒐𝒓𝒂𝑽𝟏.𝟒 𝑵𝒐𝒕 𝑬𝒏𝒄𝒓𝒊𝒑𝒕𝒆𝒅' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.owner = ['6287739797605'] // ubah aja pake nomor lu
global.pemilik = ['6287739797605']
global.wanumber = ['6287739797605'] // ketika ketik .owner
global.botname = '𝑭𝒍𝒐𝒓𝒂𝑽𝟏.𝟒 𝑵𝒐𝒕 𝑬𝒏𝒄𝒓𝒊𝒑𝒕𝒆𝒅' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
//==========================[ Masukin Apikey nya ]=======================//
global.keyopenai = '_'
//====================[ BY Hw Mods]=============================//
global.packname = '𝑭𝒍𝒐𝒓𝒂𝑽𝟏.𝟒' // ubah aja ini nama sticker
global.author = '𝑭𝒍𝒐𝒓𝒂𝑽𝟏.𝟒 𝑵𝒐𝒕 𝑬𝒏𝒄𝒓𝒊𝒑𝒕𝒆𝒅' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'FloraJkt48' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = false // true = auto blok kalo ad yg telfon
//=================================================//
// Batas User nya
global.limitawal = {
    premium: "Infinity",
    free: 1000
}
// taaofc
global.thum = fs.readFileSync("./FloraBase/image/thum.jpeg") 
global.verifsukses = fs.readFileSync ("./FloraBase/image/sukses.jpeg")
global.dash = fs.readFileSync("./FloraBase/image/dashboar.jpeg")
//=========================[ BATAS COOEG ]========================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})